Project Requires Module Gson
Provided by: https://github.com/google/gson

What to do:
--------------------------------------------------
Simple need to add to the Gradle modules:
  implementation 'com.google.code.gson:gson:2.8.9'

Sync Project
(Android Studio typically will prompt to sync project)
--------------------------------------------------

For example:
--------------------------------------------------
In location: Project Folder \ Gradle Scripts \ build.gradle (Module)
dependencies {
  implementation 'com.google.code.gson:gson:2.8.9'
}
--------------------------------------------------

Nexus 4 API 31
Resolution: 768x1280 xhdpi
Target: Android 12.0 S (Google APIs)