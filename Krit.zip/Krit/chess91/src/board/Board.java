package board;

import components.Bishop;
import components.King;
import components.Knight;
import components.Pawn;
import components.Piece;
import components.Piece.Color;
import components.Queen;
import components.Rook;

/**
 * This class defines the nature of a game board
 * @author mtr103
 */
public class Board {
	/** Enum reference rank position */
	public static enum FilePosition { 
		A(0), B(1), C(2), D(3), E(4), F(5), G(6), H(7);
		private int value;
		private FilePosition(int value) {
			this.value = value;
		}
		public int getValue() {
			return value;
		}
	}

	/** Store an array of tiles which make up a board */
	private Tile[][] tiles;
	
	/** Store whether a king has been check mated */
	private boolean checkMated;
	
	/** Store the color of the player which has won */
	private Piece.Color winner;
	
	/** Store the game rounds of a board */
	private int turn;
	
	/** Store the tile on which the white king lives */
	private Tile whiteKingTile;
	
	/** Store the file on which the black king lives */
	private Tile blackKingTile;
	
	/**
	 * Constructor for the Board
	 */
	public Board() {
		this.tiles = new Tile[8][8];
		this.checkMated = false;
		this.winner = null;
		this.turn = 1;
		this.initialize();
		this.whiteKingTile = tiles[0][FilePosition.E.getValue()];
		this.blackKingTile = tiles[7][FilePosition.E.getValue()];
	}
	
	/**
	 * Initialize a game board
	 */
	public void initialize() {
		// Set the initial state of each tile
		for (int rank = 7; rank >= 0; rank--) {
			for (int file = 0; file < 8; file++) {
				String texture = "  ";
				if (rank % 2 == 0 && file % 2 == 0 ||
					rank % 2 == 1 && file % 2 == 1 ) {
					texture = "##";
				}

				tiles[rank][file] = new Tile(rank, file, texture, null);
			}
		}
		
		// Add White's pieces to the board
		// ====================================================================
		tiles[0][FilePosition.A.getValue()].setPiece(new Rook(Color.WHITE));
		tiles[0][FilePosition.B.getValue()].setPiece(new Knight(Color.WHITE));
		tiles[0][FilePosition.C.getValue()].setPiece(new Bishop(Color.WHITE));
		tiles[0][FilePosition.D.getValue()].setPiece(new Queen(Color.WHITE));
		tiles[0][FilePosition.E.getValue()].setPiece(new King(Color.WHITE));
		tiles[0][FilePosition.F.getValue()].setPiece(new Bishop(Color.WHITE));
		tiles[0][FilePosition.G.getValue()].setPiece(new Knight(Color.WHITE));
		tiles[0][FilePosition.H.getValue()].setPiece(new Rook(Color.WHITE));
		tiles[1][FilePosition.A.getValue()].setPiece(new Pawn(Color.WHITE));
		tiles[1][FilePosition.B.getValue()].setPiece(new Pawn(Color.WHITE));
		tiles[1][FilePosition.C.getValue()].setPiece(new Pawn(Color.WHITE));
		tiles[1][FilePosition.D.getValue()].setPiece(new Pawn(Color.WHITE));
		tiles[1][FilePosition.E.getValue()].setPiece(new Pawn(Color.WHITE));
		tiles[1][FilePosition.F.getValue()].setPiece(new Pawn(Color.WHITE));
		tiles[1][FilePosition.G.getValue()].setPiece(new Pawn(Color.WHITE));
		tiles[1][FilePosition.H.getValue()].setPiece(new Pawn(Color.WHITE));
		
		// Add Black's pieces to the board
		// ====================================================================
		tiles[7][FilePosition.A.getValue()].setPiece(new Rook(Color.BLACK));
		tiles[7][FilePosition.B.getValue()].setPiece(new Knight(Color.BLACK));
		tiles[7][FilePosition.C.getValue()].setPiece(new Bishop(Color.BLACK));
		tiles[7][FilePosition.D.getValue()].setPiece(new Queen(Color.BLACK));
		tiles[7][FilePosition.E.getValue()].setPiece(new King(Color.BLACK));
		tiles[7][FilePosition.F.getValue()].setPiece(new Bishop(Color.BLACK));
		tiles[7][FilePosition.G.getValue()].setPiece(new Knight(Color.BLACK));
		tiles[7][FilePosition.H.getValue()].setPiece(new Rook(Color.BLACK));
		tiles[6][FilePosition.A.getValue()].setPiece(new Pawn(Color.BLACK));
		tiles[6][FilePosition.B.getValue()].setPiece(new Pawn(Color.BLACK));
		tiles[6][FilePosition.C.getValue()].setPiece(new Pawn(Color.BLACK));
		tiles[6][FilePosition.D.getValue()].setPiece(new Pawn(Color.BLACK));
		tiles[6][FilePosition.E.getValue()].setPiece(new Pawn(Color.BLACK));
		tiles[6][FilePosition.F.getValue()].setPiece(new Pawn(Color.BLACK));
		tiles[6][FilePosition.G.getValue()].setPiece(new Pawn(Color.BLACK));
		tiles[6][FilePosition.H.getValue()].setPiece(new Pawn(Color.BLACK));
	}
	
	/** Draw the game board */
	public void draw() {		
		for (int rank = 7; rank >= 0; rank--) {
			for (int file = 0; file < 8; file++) {

				Tile currentTile = tiles[rank][file];
				if (currentTile != null) {
					tiles[rank][file].draw();
				}
				
				System.out.print(" ");
				
				if (file + 1 > 7) {
					// Vertical labels
					System.out.println(rank+1);
				}
			}
		}
		
		// Horizontal footer
		System.out.println(" a  b  c  d  e  f  g  h\n");
	}
	
	/**
	 * Determine whether a king has been put in check
	 * @param playerColor Specify the color of a player's king
	 * @return The check status of a given king
	 */
	public boolean isKingInCheck(Piece.Color playerColor) {
		boolean isCheck = false;
		Tile kingTile = null;

		if (playerColor.equals(Piece.Color.WHITE)) {
			kingTile = this.whiteKingTile;
		} else {
			kingTile = this.blackKingTile;
		}

		for (int rank = 7; rank >= 0; rank--) {
			for (int file = 0; file < 8; file++) {
				Tile sourceTile = tiles[rank][file];
				Piece sourcePiece = sourceTile.getPiece();
				
				if (sourcePiece != null && !sourcePiece.getColor().equals(playerColor)) {
						isCheck = sourcePiece.evaluatePossibleMove(this, sourceTile, kingTile);	

					if (isCheck) {
						return isCheck;
					}
				}
			}
		}

		return isCheck;
	}
	
	/**
	 * Determine whether a game piece is able to block a position
	 * @param playerColor Specify the color of the piece to check
	 * @param blockPositionTile Specify the target location to be blocked
	 * @return Whether a given piece can block a location
	 */
	public boolean canBlock(Piece.Color playerColor, Tile blockPositionTile) {
		boolean canBlock = false;

		for (int rank = 7; rank >= 0; rank--) {
			for (int file = 0; file < 8; file++) {
				Tile sourceTile = tiles[rank][file];
				Piece sourcePiece = sourceTile.getPiece();
				
				if (sourcePiece != null && sourcePiece.getColor().equals(playerColor)) {
					canBlock = sourcePiece.evaluatePossibleMove(this, sourceTile, blockPositionTile);
					
					if (canBlock) {
						return canBlock;
					}
				}
			}
		}
		
		return canBlock;
	}
	
	/**
	 * Get the current tile of the white king
	 * @return King's tile
	 */
	public Tile getWhiteKingTile() {
		return whiteKingTile;
	}

	/**
	 * Set the current tile of the white king
	 * @param whiteKingTile Location of the white king
	 */
	public void setWhiteKingTile(Tile whiteKingTile) {
		this.whiteKingTile = whiteKingTile;
	}

	/**
	 * Get the current tile of the black king
	 * @return King's tile
	 */
	public Tile getBlackKingTile() {
		return blackKingTile;
	}

	/**
	 * Set the current tile of the black king
	 * @param blackKingTile Location of the black king
	 */
	public void setBlackKingTile(Tile blackKingTile) {
		this.blackKingTile = blackKingTile;
	}

	/**
	 * Get the current round of a game board
	 * @return The turn of a game board
	 */
	public int getTurn() {
		return turn;
	}

	/**
	 * Set the current game round
	 * @param turn Specify the round of the board
	 */
	public void setTurn(int turn) {
		this.turn = turn;
	}

	/**
	 * Get the status of a king in check mate
	 * @return Whether or not a king has been check mated
	 */
	public boolean isCheckMated() {
		return checkMated;
	}

	/**
	 * Set the status of a king in check mate
	 * @param checkMated Specify whether a check has been found
	 */
	public void setCheckMated(boolean checkMated) {
		this.checkMated = checkMated;
	}

	/**
	 * Get the winner of the game
	 * @return The color of the winner
	 */
	public Piece.Color getWinner() {
		return winner;
	}

	/**
	 * Set the winner of the game
	 * @param winner Specify the winner of the game
	 */
	public void setWinner(Piece.Color winner) {
		this.winner = winner;
	}

	/**
	 * Get the tiles of a gameboard
	 * @return The tiles of the board
	 */
	public Tile[][] getTiles() {
		return tiles;
	}
}
