package board;

import java.util.Scanner;

import components.Bishop;
import components.King;
import components.Knight;
import components.Pawn;
import components.Piece;
import components.Queen;
import components.Rook;

/**
 * This class defines the nature of a desired move
 * @author mtr103
 */
public class Move {
	/** Stores a a requested move */
	private String requestedMove;
	
	/** Stores a promotion */
	private String promotion;
	
	/** Stores a the file of source move */
	private int sourceFile;
	
	/** Stores a the rank of a source move */
	private int sourceRank;
	
	/** Stores a the file of a target move */
	private int targetFile;
	
	/** Stores a the rank of a target move */
	private int targetRank;
	
	/** Stores a the color of the mover */
	private Piece.Color playerColor;
	
	/**
	 * Constructor for the Move
	 * @param requestedMove Specify the move to be made
	 * @param playerColor Specify the color of the player
	 */
	public Move(String requestedMove, Piece.Color playerColor) {
		this.requestedMove = requestedMove;
		this.playerColor = playerColor;
		parseRequestedMove();
	}
	
	/**
	 * Constructor for the Move
	 * @param sourceFile Specify the file of the source
	 * @param sourceRank Specify the rank of the source
	 */
	public Move(int sourceFile, int sourceRank) {
		this.sourceFile = sourceFile;
		this.sourceRank = sourceRank;
		this.targetFile = 0;
		this.targetRank = 0;
	}
	
	/**
	 * Evaluate a requested move on the board
	 * @param board Specify the game board on which a move will be made
	 * @return Whether a given move is valid or not
	 */
	public boolean evaluate(Board board) {
		Tile[][] tiles = board.getTiles();
		Tile sourceTile = tiles[sourceRank][sourceFile];
		Tile targetTile = tiles[targetRank][targetFile];

		Piece sourcePiece = sourceTile.getPiece();
		Piece targetPiece = targetTile.getPiece();

		// Trying to move a piece that does not exist at location
		// Trying to move a piece that doesn't belong to the player issuing the move
		// Trying to move a piece on itself
		if (sourcePiece == null || !sourcePiece.getColor().equals(playerColor) || sourcePiece.equals(targetPiece)) {
			System.out.println("Illegal move, try again");
			return false;
		}

		// It's possible to move to location but ... let's check to see if 
		// it's a king. If so, we have to check to see if that move would
		// put the king in check. If so, invalidate the otherwise good move, and
		// report check
		Piece.Color side = sourceTile.getPiece().getColor();
		boolean isValidMove = sourcePiece.evaluatePossibleMove(board, sourceTile, targetTile);
		boolean kingInCheck = board.isKingInCheck(side);

		// Check to see if king is in current check
		// I added this late at night. 
		/*
		if (!kingInCheck) {
			sourceTile.setPiece(null);
			isValidMove = !board.isKingInCheck(side);
			sourceTile.setPiece(sourcePiece);
		}
		 */
		

		// Everything is good. Move the piece
		if (isValidMove) {

			if (targetPiece instanceof King) {
				board.setCheckMated(true);
				board.setWinner(sourcePiece.getColor());
			}
			
			sourcePiece.setHasMoved(true);
			
			// Check for promotion
			if (sourcePiece instanceof Pawn) {
				Pawn sourcePawn = (Pawn) sourcePiece;
				Tile enpassantTile = sourcePawn.getEnpassantTile();
				
				// Remove the piece behind the pass
				if (enpassantTile != null) {
					enpassantTile.setPiece(null);
				}
				
				if (sourcePiece.getColor().equals(Piece.Color.WHITE) && targetTile.getX() == 7) {
					sourcePiece = getPromotedPiece(Piece.Color.WHITE);
				} else if (sourcePiece.getColor().equals(Piece.Color.BLACK) && targetTile.getX() == 0) {
					sourcePiece = getPromotedPiece(Piece.Color.BLACK);
				}
			}
			
			targetTile.setPiece(sourcePiece);
			sourceTile.setPiece(null);

			// Valid move, update the boards references to the respective kings
			if (sourcePiece instanceof King) {
				if (sourcePiece.getColor().equals(Piece.Color.WHITE) ) {
					board.setWhiteKingTile(targetTile);
				} else {
					board.setBlackKingTile(targetTile);
				}
			}

			return true;
		} else {
			System.out.println("Illegal move, try again");
			return false;
		}
	}
	
	/**
	 * Get the rank of a tile
	 * @param color Specify the color of a piece
	 * @return A game piece specified by promotion
	 */
	private Piece getPromotedPiece(Piece.Color color) {
		Piece nPiece = null;
		
		if (promotion.equals("R")) {
			nPiece = new Rook(color);
		} else if (promotion.equals("N")) {
			nPiece = new Knight(color);
		} else if (promotion.equals("B")) {
			nPiece = new Bishop(color);
		} else if (promotion.equals("Q")) {
			nPiece = new Queen(color);
		}
		
		return nPiece;
	}
	
	/**
	 * Helper parse a requested move given by a string
	 */
	private void parseRequestedMove() {
		Scanner scanner = new Scanner(requestedMove);
		String source = scanner.next();
		String target = scanner.next();
		promotion = "Q";
		
		if (scanner.hasNext()) {
			promotion = scanner.next().toUpperCase();
		}
		
		scanner.close();
		
		char[] sourceChars = source.toUpperCase().toCharArray();
		char[] targetChars = target.toUpperCase().toCharArray();

		sourceFile = translateFile(sourceChars[0]);
		sourceRank = Character.getNumericValue(sourceChars[1]) - 1;
		
		targetFile = translateFile(targetChars[0]);
		targetRank = Character.getNumericValue(targetChars[1]) - 1;
	}
	
	/**
	 * Helper translate the position of a file
	 * @return A number of whate a file position would be
	 */
	private int translateFile(char source) {
		int file = 0;
		switch (source) {
	        case ('B'):
	        	file = 1;
	        	break;
	        case ('C'):
	        	file = 2;
	        	break;
	        case ('D'):
	        	file = 3;
	        	break;
	        case ('E'):
	        	file = 4;
	        	break;
	        case ('F'):
	        	file = 5;
	        	break;
	        case ('G'):
	        	file = 6;
	        	break;
	        case ('H'):
	        	file = 7;
	        	break;
		}
		return file;
	}

	/**
	 * Get the file of a source move
	 * @return Source File
	 */
	public int getSourceFile() {
		return sourceFile;
	}

	/**
	 * Set the file of a source move
	 * @param sourceFile Specify the file of a given source
	 */
	public void setSourceFile(int sourceFile) {
		this.sourceFile = sourceFile;
	}

	/**
	 * Get the rank of a source move
	 * @return Source rank
	 */
	public int getSourceRank() {
		return sourceRank;
	}

	/**
	 * Set the rank of a source move
	 * @param sourceRank Specify the rank of a given source
	 */
	public void setSourceRank(int sourceRank) {
		this.sourceRank = sourceRank;
	}

	/**
	 * Get the file of a target move
	 * @return Target File
	 */
	public int getTargetFile() {
		return targetFile;
	}

	/**
	 * Set the file of a target move
	 * @param targetFile Specify the file of a given target
	 */
	public void setTargetFile(int targetFile) {
		this.targetFile = targetFile;
	}

	/**
	 * Get the rank of a target move
	 * @return Target Rank
	 */
	public int getTargetRank() {
		return targetRank;
	}

	/**
	 * Set the rank of a target move
	 * @param targetRank Specify the rank of a given target
	 */
	public void setTargetRank(int targetRank) {
		this.targetRank = targetRank;
	}

	/**
	 * Determine if a move is equal to another move
	 * @return Whether or not a given move is equal to another
	 */
	@Override
    public boolean equals(Object o) {
		if (o instanceof Move ) {
			Move object = (Move)o;
			return this.sourceFile == object.getSourceFile() && this.sourceRank == object.getSourceRank();
		}
		return false;
	}
}
