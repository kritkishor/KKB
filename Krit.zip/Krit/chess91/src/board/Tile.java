package board;

import components.Piece;

/**
 * This class defines the nature of a tile of a game board
 * @author mtr103
 */
public class Tile {
	/** Stores a chess piece */
	private Piece piece;
	
	/** Stores the texture */
	private String texture;
	
	/** Stores the rank of a tile */
	private int x;
	
	/** Stores the file of a tile */
	private int y;
	
	/**
	 * Constructor for the Piece
	 * @param x Specify the rank of a tile
	 * @param y Specify the file of a tile
	 * @param texture Specify the texture of a tile
	 * @param piece Specify the piece of a tile
	 */
	public Tile(int x, int y, String texture, Piece piece) {
		this.x = x;
		this.y = y;
		this.texture = texture;
		this.piece = piece;
	}

	/**
	 * Get the rank of a tile
	 * @return Rank of a tile
	 */
	public int getX() {
		return x;
	}

	/**
	 * Get the file of a tile
	 * @return File of a tile
	 */
	public int getY() {
		return y;
	}
	
	/**
	 * Get the the piece on a tile
	 * @return Chess piece of the tile
	 */
	public Piece getPiece() {
		return piece;
	}

	/**
	 * Get the texture of a tile
	 * @return Texture of a tile
	 */
	public String getTexture() {
		return texture;
	}
	
	/**
	 * Set the rank of a tile
	 * @param x Rank to set
	 */
	public void setX(int x) {
		this.x = x;
	}

	/**
	 * Set the file of a tile
	 * @param y File to set
	 */
	public void setY(int y) {
		this.y = y;
	}
	
	/**
	 * Set the texture of a tile
	 * @param texture Texture to set
	 */
	public void setTexture(String texture) {
		this.texture = texture;
	}

	/**
	 * Set the piece of a tile
	 * @param piece Piece to set
	 */
	public void setPiece(Piece piece) {
		this.piece = piece;
	}
	
	/**
	 * Draw a given tile
	 */
	public void draw() {
		if (piece == null) {
			System.out.print(texture);
		} else {
			System.out.print(piece);			
		}
	}
}
