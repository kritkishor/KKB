package chess;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import board.Board;
import board.Move;
import components.Piece;

/**
 * This class defines the client of a chess game
 * @author mtr103
 */
public class Chess {

	/**
	 * Main method
	 * @param args The command line arguments
	 **/
	public static void main(String[] args) {

		Board board = new Board();

		String requestedMove;
		boolean gameIsOver = false;
		boolean whiteTurn = true;
		String gameMessage = "";
		String promptMessage = "";
		Piece.Color playerColor;
		
		while (true) {

			if (board.isCheckMated()) {
				System.out.println("Checkmate");
				if (board.getWinner().equals(Piece.Color.WHITE)) {
					System.out.println("White wins");
				} else {
					System.out.println("Black wins");
				}
				break;
			}

			// ===============================
			// White's turn
			// ===============================
			boolean isValidMove = false;
			
			if (whiteTurn) {
				promptMessage = "White's move: ";
				gameMessage = "Black wins";
				playerColor = Piece.Color.WHITE;
			} else {
				playerColor = Piece.Color.BLACK;
				promptMessage = "Black's move: ";
				gameMessage = "White wins";
			}
			
			// draw board
			board.draw();
			
			if (board.isKingInCheck(playerColor)) {
				System.out.println("Check\n");
			}
		
			// prompt player for move
			System.out.print(promptMessage);
			requestedMove = null;
			requestedMove = getUserInputMove();
			
			// check move
			if (requestedMove.equalsIgnoreCase("resign")) {
				gameIsOver = true;
			} else if (requestedMove.toLowerCase().contains("draw?")) {
				gameIsOver = true;
				gameMessage = "draw";
			}
	
			if (gameIsOver == true) {
				System.out.println(gameMessage);
				break;
			}
			
			// do move			
			Move nMove = new Move(requestedMove, playerColor);
			isValidMove = nMove.evaluate(board);

			if (whiteTurn && isValidMove) {
				whiteTurn = false;
				board.setTurn(board.getTurn() + 1);
			} else if (!whiteTurn && isValidMove) {
				whiteTurn = true;
				board.setTurn(board.getTurn() + 1);
			}
			
			System.out.println("");
		}
	}
	
	/**
	 * Determin a move to be made by a player
	 * @return The requested move made by a player
	 **/
	public static String getUserInputMove() {
		// Acceptable inputs
		// =======================================================================================================
		// User enters: resign (^[rR][eE][sS][iI][gG][nN])
		// User enters: draw (^[dD][rR][aA][wW])
		// User enters: FileRank FileRank draw? (^[a-hA-H][1-8][ ][a-hA-H][1-8][ ][dD][rR][aA][wW]\\?)
		// User enters: FileRank FileRank P, where P is a piece (^[a-hA-H][1-8][ ][a-hA-H][1-8][ ][rRnNbBqQ]$)
		// User enters: FileRank FileRank (^[a-hA-H][1-8][ ][a-hA-H][1-8]$)
		// =======================================================================================================
		
		String userInput = null;
		String pattern = "(?m)(^[rR][eE][sS][iI][gG][nN])|(^[dD][rR][aA][wW]$)|(^[a-hA-H][1-8][ ][a-hA-H][1-8][ ][dD][rR][aA][wW]\\?)|(^[a-hA-H][1-8][ ][a-hA-H][1-8][ ][rRnNbBqQ]$)|(^[a-hA-H][1-8][ ][a-hA-H][1-8]$)";
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		try {
			while (true) {
				String rawLine = reader.readLine();
				Scanner scanner = new Scanner(rawLine);
				userInput = scanner.findInLine(pattern);
				scanner.close();
				
				if (userInput != null) {
					break;
				} else {
					System.out.println("Illegal move, try again");
				}
			}
		} catch (IOException e) {
			System.out.println("Illegal move, try again");
		}
		
		return userInput;
	}
}
