package components;

import java.util.LinkedList;

import board.Board;
import board.Move;
import board.Tile;

/**
 * This class defines the nature of a Bishop piece
 * @author mtr103
 */
public class Bishop extends Piece {
	
	/**
	 * Constructor for the Bishop
	 * @param color The color to set the chess piece
	 *  
	 */
	public Bishop(Piece.Color color) {
		super(color);
	}

	/**
	 * Convert a color to a string
	 * @return The the color of a given chess piece
	 */
	@Override
	public String toString() {
		return (super.getColor() == Piece.Color.WHITE ? "w" : "b" ) + "B";
	}

	/**
	 * Evaluate possible moves of a given chess piece
	 * @param board Game board
	 * @param tileS Source tile of a given move
	 * @param tileT Target tile of a given move
	 * @return Confirmation of whether a move is valid or not
	 */
	@Override
	public boolean evaluatePossibleMove(Board board, Tile tileS, Tile tileT) {
		LinkedList<Move> possibleTargets = new LinkedList<>();
		Tile[][] tiles = board.getTiles();
		
		boolean isValid = false;

		int sx = tileS.getX();
		int sy = tileS.getY();
		
		int tx = tileT.getX();
		int ty = tileT.getY();

		int rise = ty - sy;
		int run = tx - sx;

		if (rise == 0 || run == 0) {
			return isValid;
		}
		
		int directionX = run / Math.abs(run);
		int directionY = rise / Math.abs(rise);
		
		int cx = sx + directionX;
		int cy = sy + directionY;
		
		while ((cx >= 0 && cx < 8) && (cy >= 0 && cy < 8)) {
			Move nMove = new Move(cx, cy);
			possibleTargets.addLast(nMove);
			cx = cx + directionX;
			cy = cy + directionY;
		}

		// Our target destination exists in the list
		Move targetMove = new Move(tileT.getX(), tileT.getY());
		isValid = possibleTargets.contains(targetMove);
		
		if (isValid == true) {
			for (Move m : possibleTargets) {
				Tile tile = tiles[m.getSourceFile()][m.getSourceRank()];
				Piece piece = tile.getPiece();
				
				if (piece != null) {
					// ran through the list and made it to the target
					if (m.equals(targetMove)) {
						break;
					} else {
						// ran into something in the road and it isn't the final destination
						isValid = false;
						break;
					}
				} else { // *** Added late. Come back here and verify ***
					if (m.equals(targetMove)) {
						isValid = true;
						break;
					}
				}
				
			}
			
			if (isValid) {
				if (tileT.getPiece() != null) {
					String sourceS = tileS.getPiece().getColor().name();
					String targetS = tileT.getPiece().getColor().name();
					isValid = !sourceS.equals(targetS);
				}
			}
		}	
		return isValid;
	}
}
