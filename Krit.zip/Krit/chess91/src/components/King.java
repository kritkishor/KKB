package components;

import java.util.ArrayList;

import board.Board;
import board.Board.FilePosition;
import board.Move;
import board.Tile;

/**
 * This class defines the nature of a King piece
 * @author mtr103
 */
public class King extends Piece {
	
	/**
	 * Constructor for the King
	 * @param color The color to set the chess piece
	 *  
	 */
	public King(Piece.Color color) {
		super(color);
	}

	/**
	 * Convert a color to a string
	 * @return The the color of a given chess piece
	 */
	@Override
	public String toString() {
		return (super.getColor() == Piece.Color.WHITE ? "w" : "b" ) + "K";
	}

	/**
	 * Evaluate possible moves of a given chess piece
	 * @param board Game board
	 * @param tileS Source tile of a given move
	 * @param tileT Target tile of a given move
	 * @return Confirmation of whether a move is valid or not
	 */
	@Override
	public boolean evaluatePossibleMove(Board board, Tile tileS, Tile tileT) {
		boolean isValid = false;

		ArrayList<Move> possibleTargets = new ArrayList<>();
		Tile[][] tiles = board.getTiles();
		
		int sx = tileS.getX();
		int sy = tileS.getY();

		int ty = tileT.getY();
		
		// before adding to list, we check to see if move is in bounds
		// and an ally doesn't exist on the tile already
		possibleTargets.add(new Move(sx - 1, sy));
		possibleTargets.add(new Move(sx + 1, sy));
		possibleTargets.add(new Move(sx, sy + 1));
		possibleTargets.add(new Move(sx, sy - 1));
		possibleTargets.add(new Move(sx - 1, sy + 1));
		possibleTargets.add(new Move(sx - 1, sy - 1));
		possibleTargets.add(new Move(sx + 1, sy + 1));
		possibleTargets.add(new Move(sx + 1, sy - 1));
		
		King king = (King) tileS.getPiece();
		Tile rookTile = null;
		Tile nextToKingTile = null;
		Tile castlingTile = null;
		Move castlingMove = null;
		Rook rook = null;
		
		if (sy < ty) {
			rookTile = tiles[sx][FilePosition.H.getValue()];
			nextToKingTile = tiles[sx][FilePosition.F.getValue()];
			castlingTile = tiles[sx][FilePosition.G.getValue()];
			castlingMove = new Move(sx, sy + 2);
		} else {
			rookTile = tiles[sx][FilePosition.A.getValue()];
			nextToKingTile = tiles[sx][FilePosition.D.getValue()];
			castlingTile = tiles[sx][FilePosition.C.getValue()];
			castlingMove = new Move(sx, sy - 2);
		}
		
		Piece rookTilePiece = rookTile.getPiece();
		if (rookTilePiece instanceof Rook) {
			rook = (Rook) rookTilePiece;
		}
		
		// king has not moved and rook has not moved, and king is not in current check
		if (!king.isHasMoved() && rook != null && !rook.isHasMoved()) {
			
			// Check to see if there are pieces between the king and rook
			boolean allClear = rook.evaluatePossibleMove(board, rookTile, nextToKingTile);
			
			// No pieces are between the King and Rook
			if (allClear) {
				possibleTargets.add(castlingMove);
			}
		}
		
		Move desiredMove = new Move(tileT.getX(), tileT.getY());
		isValid = possibleTargets.contains(desiredMove);
		

		if (isValid) {
			if (castlingMove.equals(desiredMove)) {
				nextToKingTile.setPiece(rook);
				rookTile.setPiece(null);	
			}
			
			if (tileT.getPiece() != null) {
				String sourceS = tileS.getPiece().getColor().name();
				String targetS = tileT.getPiece().getColor().name();
				isValid = !sourceS.equals(targetS);
			}
		}
		
		return isValid;
	}
}
