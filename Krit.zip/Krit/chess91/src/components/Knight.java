package components;

import java.util.ArrayList;

import board.Board;
import board.Move;
import board.Tile;

/**
 * This class defines the nature of a Knight piece
 * @author mtr103
 */
public class Knight extends Piece {

	/**
	 * Constructor for the Knight
	 * @param color The color to set the chess piece
	 *  
	 */
	public Knight(Piece.Color color) {
		super(color);
	}
	
	/**
	 * Convert a color to a string
	 * @return The the color of a given chess piece
	 */
	@Override
	public String toString() {
		return (super.getColor() == Piece.Color.WHITE ? "w" : "b" ) + "N";
	}

	/**
	 * Evaluate possible moves of a given chess piece
	 * @param board Game board
	 * @param tileS Source tile of a given move
	 * @param tileT Target tile of a given move
	 * @return Confirmation of whether a move is valid or not
	 */
	@Override
	public boolean evaluatePossibleMove(Board board, Tile tileS, Tile tileT) {
		boolean isValid = false;

		ArrayList<Move> possibleTargets = new ArrayList<>();

		int sx = tileS.getX();
		int sy = tileS.getY();
		
		// before adding to list, we check to see if move is in bounds
		// and an ally doesn't exist on the tile already
		possibleTargets.add(new Move(sx - 2, sy + 1));
		possibleTargets.add(new Move(sx - 2, sy - 1));
		possibleTargets.add(new Move(sx - 1, sy + 2));
		possibleTargets.add(new Move(sx - 1, sy - 2));
		possibleTargets.add(new Move(sx + 1, sy + 2));
		possibleTargets.add(new Move(sx + 1, sy - 2));
		possibleTargets.add(new Move(sx + 2, sy + 1));
		possibleTargets.add(new Move(sx + 2, sy - 1));
			
		isValid = possibleTargets.contains(new Move(tileT.getX(), tileT.getY()));
		
		if (isValid) {
			if (tileT.getPiece() != null) {
				String sourceS = tileS.getPiece().getColor().name();
				String targetS = tileT.getPiece().getColor().name();
				isValid = !sourceS.equals(targetS);
			}
		}
		
		return isValid;
	}
}
