package components;

import java.util.ArrayList;

import board.Board;
import board.Move;
import board.Tile;

/**
 * This class defines the nature of a Pawn piece
 * @author mtr103
 */
public class Pawn extends Piece {
	
	/** Stores whether a pawn has taken a double move */
	private int doubleMoveTurn;
	
	/** Stores the tile selected during an en passant */
	private Tile enpassantTile;

	/**
	 * Constructor for the Pawn
	 * @param color The color to set the chess piece
	 *  
	 */
	public Pawn(Piece.Color color) {
		super(color);
		this.doubleMoveTurn = 0;
		this.enpassantTile = null;
	}
	
	/**
	 * Get the en passant tile of a pawn piece
	 * @return A tile on the game board
	 */
	public Tile getEnpassantTile() {
		return enpassantTile;
	}

	/**
	 * Set the en passant tile of a pawn piece
	 * @param enpassantTile The en passant tile
	 */
	public void setEnpassantTile(Tile enpassantTile) {
		this.enpassantTile = enpassantTile;
	}

	/**
	 * Convert a color to a string
	 * @return The the color of a given chess piece
	 */
	@Override
	public String toString() {
		return (super.getColor() == Piece.Color.WHITE ? "w" : "b" ) + "p";
	}

	/**
	 * Evaluate possible moves of a given chess piece
	 * @param board Game board
	 * @param tileS Source tile of a given move
	 * @param tileT Target tile of a given move
	 * @return Confirmation of whether a move is valid or not
	 */
	@Override
	public boolean evaluatePossibleMove(Board board, Tile tileS, Tile tileT) {
		boolean isValid = true;

		ArrayList<Move> possibleMoves = new ArrayList<>();
		
		Tile[][] tiles = board.getTiles();
		
		int sx = tileS.getX();
		int sy = tileS.getY();
		
		int direction = 1;
		
		Pawn pawn = (Pawn) tileS.getPiece();
		
		if (pawn.getColor().equals(Piece.Color.BLACK)) {
			direction = -1;
		}
		
		// Standard move forward
		Piece firstMovePiece = tiles[sx + (1 * direction)][sy].getPiece();
		Move firstMove = null;
		if (firstMovePiece == null) {
			firstMove = new Move(sx + (1 * direction), sy);
			possibleMoves.add(firstMove);	
		}

		// Double move, if pawn has not moved yet
		Move doubleMove = null;
		if (!pawn.isHasMoved()) {
			Piece secondMovePiece = tiles[sx + (2 * direction)][sy].getPiece();
			
			if (firstMovePiece == null && secondMovePiece == null) {
				doubleMove = new Move(sx + (2 * direction), sy);
				possibleMoves.add(doubleMove);		
			}
		}
	
		// gotta check boundries
		
		// Check left and right corner possibilities
		int cxL = sx + (1 * direction);
		int cyL = sy + (-1 * direction);

		Piece leftCornerPiece = null;
		if (cxL >= 0 && cxL < 8 && cyL >= 0 && cyL < 8) {
			leftCornerPiece = tiles[cxL][cyL].getPiece();
			
			if (leftCornerPiece != null && !leftCornerPiece.getColor().equals(pawn.getColor())) {
				possibleMoves.add(new Move(cxL, cyL));
			}
			
			Tile leftTile = tiles[sx][sy + (-1 * direction)];
			Piece leftTilePiece = leftTile.getPiece();
			
			if (leftTilePiece != null && leftTilePiece instanceof Pawn) {
				Pawn leftPawn = (Pawn) leftTilePiece;
				if ((board.getTurn() - leftPawn.doubleMoveTurn) == 1 && !leftPawn.getColor().equals(pawn.getColor())) {
					pawn.enpassantTile = leftTile;
					possibleMoves.add(new Move(cxL, cyL));
				}
			}
		}
		
		int cxR = sx + (1 * direction);
		int cyR = sy + (1 * direction);
		
		Piece rightCornerPiece = null;
		if (cxR >= 0 && cxR < 8 && cyR >= 0 && cyR < 8) {
			rightCornerPiece = tiles[cxR][cyR].getPiece();
			
			if (rightCornerPiece != null && !rightCornerPiece.getColor().equals(pawn.getColor())) {
				possibleMoves.add(new Move(cxR, cyR));	
			}
			
			Tile rightTile = tiles[sx][sy + (1 * direction)];
			Piece rightTilePiece = rightTile.getPiece();
			
			if (rightTilePiece != null && rightTilePiece instanceof Pawn) {
				Pawn rightPawn = (Pawn) rightTilePiece;
				if ((board.getTurn() - rightPawn.doubleMoveTurn) == 1 && !rightPawn.getColor().equals(pawn.getColor())) {
					pawn.enpassantTile = rightTile;
					possibleMoves.add(new Move(cxR, cyR));	
				}
			}
		}

		// Try adding en passant move to the list of moves
		
		// check left or right of the pawn.
		// if there is a bad guy, check to see if its a pawn
		// if so, check to see what round you are in and if it is a difference of 1
		// add the move.

		
		Move targetMove = new Move(tileT.getX(), tileT.getY());	
		isValid = possibleMoves.contains(targetMove);
		
		// Make note of when the pawn has done a doubleMove
		// For use with en passant
		if (isValid) {
			// Take note of when a double move has happened
			if (doubleMove != null && doubleMove.equals(targetMove)) {
				pawn.doubleMoveTurn = board.getTurn();	
			}
		}

		return isValid;
	}
}
