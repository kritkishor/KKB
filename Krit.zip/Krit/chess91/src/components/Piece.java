package components;

import board.Board;
import board.Tile;

/**
 * This class defines the nature of an abstract chess piece
 * @author mtr103
 */
public abstract class Piece {
	
	/** Stores whether a piece had moved or not */
	private boolean hasMoved;
	
	/** Enum to be used to determine color */
	public static enum Color { WHITE, BLACK };
	
	/** Store a color of a piece */
	private Piece.Color color;

	/**
	 * Constructor for the Piece
	 * @param color The color to set the chess piece
	 */
	public Piece(Piece.Color color) {
		this.color = color;
		this.hasMoved = false;
	}
	
	/**
	 * Get the color of a given piece
	 * @return Returns the color of a piece
	 */
	public Piece.Color getColor() {
		return color;
	}
	
	/**
	 * Set the color of a given piece
	 * @param color Color of a piece
	 */
	public void setColor(Piece.Color color) {
		this.color = color;
	}

	/**
	 * Determine if a piece has moved
	 * @return Confirmation of whether a piece has moved
	 */
	public boolean isHasMoved() {
		return hasMoved;
	}

	/**
	 * Allows one to set whether a piece has moved on the board
	 * @param hasMoved Flag to set a piece has moved
	 */
	public void setHasMoved(boolean hasMoved) {
		this.hasMoved = hasMoved;
	}

	/**
	 * Evaluate possible moves of a given chess piece
	 * @param board Game board
	 * @param tileS Source tile of a given move
	 * @param tileT Target tile of a given move
	 * @return Confirmation of whether a move is valid or not
	 */
	public abstract boolean evaluatePossibleMove(Board board, Tile tileS, Tile tileT);
	
	/**
	 * Convert a color to a string
	 * @return The the color of a given chess piece
	 */
	@Override
	public abstract String toString();
}
